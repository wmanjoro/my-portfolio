from django.db import models

class CV_Model(models.Model):
    pass
